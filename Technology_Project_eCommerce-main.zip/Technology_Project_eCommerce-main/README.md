This project is designed to do the following:
  1. Create a Database and Table in Hive.
  2. Load data into the newly created table from an HDFS location.
  3. Analyze the Table using Spark.SQl.
  4. Output temporary views of the data refined into a more valuable insight for making correlations and/or improvements.
